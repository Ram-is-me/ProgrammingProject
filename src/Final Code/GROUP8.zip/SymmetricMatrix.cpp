#include "symmetricmatrix.h"

SymmetricMatrix::SymmetricMatrix(int is) : Matrix(is, is)
{

}

SymmetricMatrix::SymmetricMatrix()
{
    
}