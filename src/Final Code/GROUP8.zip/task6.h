#ifndef TASK6_H
#define TASK6_H

#include "symmetricmatrix.h"

#include <vector>

std::vector<int> min_degree_algo(std::vector<std::vector<double>> matrix);// l is the size of given matrix

#endif