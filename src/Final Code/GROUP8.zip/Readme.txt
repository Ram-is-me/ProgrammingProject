Simple Tabular Data Processing Toolkit Project

Group - 8

Task1 - Ram S IMT2017521
Task5 - Sai Venkatesh IMT2017012
Task6 - Jurair Hamid Bhat IMT2017509
Task7 - Lakshay Aggarwal IMT2017026
Task8 - Laharii IMT2017041

The program must be compiled with -std=c++17 option. The command is:
g++ -std=c++17 *.cpp

Sample input files have been provided which can be used, or own can be supplied.
It must be made sure that the format of the input file is the same as the sample provided.

Each Task has been written by that corresponding assigned person.
This is the final and only version to be considered for grading for everyone.